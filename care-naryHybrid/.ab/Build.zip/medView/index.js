'use strict';

app.models.medView = (function() {
    return {};
})();
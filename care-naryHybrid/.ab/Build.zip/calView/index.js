'use strict';

app.models.calView = (function() {
    return {};
})();
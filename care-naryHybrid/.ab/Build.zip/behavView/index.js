'use strict';

app.models.behavView = (function() {
    return {};
})();
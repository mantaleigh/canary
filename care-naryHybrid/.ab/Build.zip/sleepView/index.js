'use strict';

app.models.sleepView = (function() {
    return {};
})();
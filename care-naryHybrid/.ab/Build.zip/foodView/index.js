'use strict';

app.models.foodView = (function() {
    return {};
})();
'use strict';

app.models.actView = (function() {
    return {};
})();
'use strict';

app.models.home = (function() {
    return {};
})();
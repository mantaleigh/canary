'use strict';

(function() {
    //create a reference for the data provider to be used throughout the app

    app.data.careBackend = new Everlive({
        apiKey: 'TiQ179pLOVoq4iN1',

        scheme: 'https'
    });

}());